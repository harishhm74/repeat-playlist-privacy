/* Content script for youtube.com. Runs in the page's own context so it can use YouTube's player. */
(function () {
  'use strict';
  if (window.top !== window.self) return;

  var KEY = 'rpp.state.v1';
  // If YouTube's own player refuses a speed your account is entitled to, set it on the <video> element
  // directly (the way common speed-controller extensions do). Set to false to use only YouTube's player API.
  var ALLOW_DIRECT_RATE = true;

  // ---------- plan parsing and queue logic (same rules as player.html) ----------
  function extractId(s) {
    s = String(s || '').trim();
    if (/^[A-Za-z0-9_-]{11}$/.test(s)) return s;
    var m = s.match(/(?:v=|youtu\.be\/|shorts\/|embed\/|live\/)([A-Za-z0-9_-]{11})/);
    if (!m) throw new Error('no video ID found in "' + s + '"');
    return m[1];
  }
  function parseTime(t) {
    if (t == null || String(t).trim() === '') return null;
    t = String(t).trim();
    if (/^\d+(\.\d+)?$/.test(t)) return Number(t);
    var parts = t.split(':').map(Number);
    if (parts.length > 3 || parts.some(function (n) { return isNaN(n); })) throw new Error('bad time "' + t + '"');
    return parts.reduce(function (a, n) { return a * 60 + n; }, 0);
  }
  function parsePlan(text) {
    var items = [], errors = [];
    String(text).split(/\r?\n/).forEach(function (raw, i) {
      var line = raw.trim();
      if (!line || line.charAt(0) === '#') return;           // blank, comment, #loop or #off lines
      var main = line.split(/\s+#/)[0];
      var p = main.split(',').map(function (x) { return x.trim(); });
      try {
        var it = { id: extractId(p[0]), repeats: p[1] ? Number(p[1]) : 1, speed: p[2] ? Number(p[2]) : 1, start: parseTime(p[3]), end: parseTime(p[4]) };
        if (!(Number.isInteger(it.repeats) && it.repeats >= 1 && it.repeats <= 999)) throw new Error('repeats must be 1 to 999');
        if (!(it.speed >= 0.25 && it.speed <= 4)) throw new Error('speed must be 0.25 to 4');
        if (it.start != null && it.end != null && it.end <= it.start) throw new Error('end must be after start');
        items.push(it);
      } catch (e) { errors.push('Line ' + (i + 1) + ': ' + e.message); }
    });
    return { items: items, errors: errors, loop: /^\s*#loop\s*$/m.test(text) };
  }
  function nextPos(items, idx, rep, loop) {
    if (rep < items[idx].repeats) return { idx: idx, rep: rep + 1 };
    if (idx + 1 < items.length) return { idx: idx + 1, rep: 1 };
    return loop ? { idx: 0, rep: 1 } : null;
  }
  function prevPos(items, idx, rep) {
    if (rep > 1) return { idx: idx, rep: rep - 1 };
    if (idx > 0) return { idx: idx - 1, rep: items[idx - 1].repeats };
    return { idx: 0, rep: 1 };
  }

  // ---------- state ----------
  var state = null;
  try { state = JSON.parse(localStorage.getItem(KEY)); } catch (e) { state = null; }
  function save() { try { localStorage.setItem(KEY, JSON.stringify(state)); } catch (e) {} }

  var loading = false, loadDeadline = 0, settleUntil = 0, navigating = false, hudMessage = '';

  function cur() { return state && state.items[state.idx]; }

  function startPlan(text) {
    var r = parsePlan(text);
    if (r.errors.length) { setMsg(r.errors.join('  |  ')); return false; }
    if (!r.items.length) { setMsg('The plan has no videos.'); return false; }
    state = { items: r.items, idx: 0, rep: 1, loop: r.loop, active: true };
    save(); loading = false; navigating = false; setMsg('');
    playCurrent(false);
    return true;
  }
  function stopPlan() { if (state) { state.active = false; save(); } setMsg('Stopped.'); }

  // ---------- YouTube player access ----------
  function getPlayer() { return document.querySelector('#movie_player') || document.querySelector('.html5-video-player'); }
  function getVideo() { return document.querySelector('video.html5-main-video') || document.querySelector('video'); }
  function adShowing(p) { return !!(p && p.classList && p.classList.contains('ad-showing')); }
  function currentVideoId(p) {
    try { var d = p && p.getVideoData && p.getVideoData(); if (d && d.video_id) return d.video_id; } catch (e) {}
    try { return new URL(location.href).searchParams.get('v'); } catch (e) { return null; }
  }

  function playCurrent(sameId) {
    var it = cur(), p = getPlayer();
    if (!it) return;
    settleUntil = Date.now() + 2000;
    if (p && sameId && typeof p.seekTo === 'function') {
      p.seekTo(it.start || 0, true);
      if (typeof p.playVideo === 'function') p.playVideo();
      loading = false;
      return;
    }
    if (p && typeof p.loadVideoById === 'function' && location.pathname === '/watch') {
      loading = true; loadDeadline = Date.now() + 8000;
      p.loadVideoById({ videoId: it.id, startSeconds: it.start || 0 });
      return;
    }
    navigateTo(it);
  }
  function navigateTo(it) {
    if (navigating) return;
    navigating = true;
    location.assign('/watch?v=' + it.id + (it.start ? '&t=' + Math.floor(it.start) + 's' : ''));
  }

  function advance(kind) {
    if (!state || !state.active) return;
    var items = state.items, before = items[state.idx].id;
    var pos = kind === 'prev' ? prevPos(items, state.idx, state.rep) : nextPos(items, state.idx, state.rep, state.loop);
    if (!pos) { state.active = false; save(); setMsg('Finished the plan.'); return; }
    state.idx = pos.idx; state.rep = pos.rep; save();
    playCurrent(items[state.idx].id === before);
  }

  function applyRate(p, v, target) {
    try { if (p.getPlaybackRate && Math.abs(p.getPlaybackRate() - target) > 0.001) p.setPlaybackRate(target); } catch (e) {}
    if (ALLOW_DIRECT_RATE && v && Math.abs(v.playbackRate - target) > 0.001) { try { v.playbackRate = target; } catch (e) {} }
  }

  // ---------- main loop ----------
  function tick() {
    if (!state || !state.active) { updateHud(); return; }
    var it = cur(), p = getPlayer(), v = getVideo();
    if (!it) return;
    if (!p || !v) {
      if (location.pathname !== '/watch') navigateTo(it);
      updateHud(); return;
    }
    var vid = currentVideoId(p);
    if (vid !== it.id) {
      if (!loading) playCurrent(false);
      else if (Date.now() > loadDeadline) { loading = false; navigateTo(it); }
      updateHud(); return;
    }
    loading = false;
    if (adShowing(p)) { updateHud(); return; }            // never touch ads
    applyRate(p, v, it.speed);
    if (Date.now() > settleUntil) {
      var ended = v.ended || (p.getPlayerState && p.getPlayerState() === 0);
      var pastEnd = it.end != null && v.currentTime >= it.end;
      if (ended || pastEnd) advance('next');
    }
    updateHud();
  }

  // ---------- on-page controls (built with createElement; YouTube blocks innerHTML) ----------
  var hud = null, ui = {};
  function h(tag, css, text) {
    var n = document.createElement(tag);
    if (css) n.style.cssText = css;
    if (text != null) n.textContent = text;
    return n;
  }
  var BTN = 'font:12px system-ui,sans-serif;color:#e8eaed;background:#232830;border:1px solid #3a4048;border-radius:6px;padding:4px 8px;cursor:pointer;';
  function btn(label, title, fn) {
    var b = h('button', BTN, label); b.type = 'button'; b.title = title; b.setAttribute('aria-label', title);
    b.addEventListener('click', function (e) { e.stopPropagation(); fn(); });
    return b;
  }
  function buildHud() {
    if (hud || !document.body) return;
    hud = h('div', 'position:fixed;left:8px;bottom:8px;z-index:2147483647;background:rgba(16,18,20,.94);color:#e8eaed;font:12px system-ui,sans-serif;border:1px solid #2a2f35;border-radius:8px;padding:6px 8px;max-width:calc(100vw - 16px);display:flex;flex-direction:column;gap:6px;');
    hud.id = 'rpp-hud';
    ui.status = h('div', 'line-height:1.35;overflow-wrap:anywhere;', 'Repeat Playlist: no plan loaded');
    var row = h('div', 'display:flex;gap:6px;flex-wrap:wrap;');
    ui.prev = btn('⏮', 'Previous', function () { if (state && state.active) advance('prev'); });
    ui.pause = btn('⏯', 'Pause or resume', function () {
      var p = getPlayer(); if (!p || !p.getPlayerState) return;
      if (p.getPlayerState() === 1) p.pauseVideo(); else p.playVideo();
    });
    ui.next = btn('⏭', 'Next', function () { if (state && state.active) advance('next'); });
    ui.stop = btn('Stop', 'Stop the plan', stopPlan);
    ui.plan = btn('Plan', 'Paste or edit the plan', function () { ui.panel.style.display = ui.panel.style.display === 'none' ? 'flex' : 'none'; });
    [ui.prev, ui.pause, ui.next, ui.stop, ui.plan].forEach(function (b) { row.appendChild(b); });
    ui.panel = h('div', 'display:none;flex-direction:column;gap:6px;width:min(420px,calc(100vw - 32px));');
    ui.text = h('textarea', 'width:100%;min-height:110px;background:#0d0f11;color:#e8eaed;border:1px solid #2a2f35;border-radius:6px;padding:6px;font:12px ui-monospace,Menlo,monospace;');
    ui.text.placeholder = 'Paste the plan from the editor page:\nVIDEO_ID, repeats, speed, start, end\n(add a line #loop to loop the whole plan)';
    ui.text.spellcheck = false;
    ui.text.addEventListener('keydown', function (e) { e.stopPropagation(); });
    ui.text.addEventListener('keyup', function (e) { e.stopPropagation(); });
    ui.go = btn('Start plan', 'Start playing this plan', function () { startPlan(ui.text.value); });
    ui.panel.appendChild(ui.text); ui.panel.appendChild(ui.go);
    hud.appendChild(ui.status); hud.appendChild(row); hud.appendChild(ui.panel);
    document.body.appendChild(hud);
  }
  function setMsg(t) { hudMessage = t || ''; updateHud(); }
  function updateHud() {
    if (!document.body) return;
    if (!hud || !hud.isConnected) { hud = null; buildHud(); }
    if (!hud) return;
    var line;
    if (state && state.active) {
      var it = cur(), p = getPlayer(), title = '';
      try { var d = p && p.getVideoData && p.getVideoData(); if (d && d.title && d.video_id === it.id) title = d.title; } catch (e) {}
      line = 'Video ' + (state.idx + 1) + ' of ' + state.items.length + ', play ' + state.rep + ' of ' + it.repeats +
        ', speed ' + it.speed + '×' + (title ? ' · ' + title : '');
      if (p && adShowing(p)) line += ' (ad playing)';
    } else {
      line = 'Repeat Playlist: ' + (hudMessage || 'no plan running. Tap Plan to paste one.');
    }
    if (state && state.active && hudMessage) line += ' · ' + hudMessage;
    if (ui.status.textContent !== line) ui.status.textContent = line;
  }

  // ---------- start from a link made by the editor page: youtube.com/watch?v=ID#rpp=<base64url plan> ----------
  function fromHash() {
    var m = location.hash.match(/^#rpp=([A-Za-z0-9_-]+)/);
    if (!m) return;
    var text;
    try {
      var b64 = m[1].replace(/-/g, '+').replace(/_/g, '/');
      text = decodeURIComponent(escape(atob(b64)));
    } catch (e) { return; }
    try { history.replaceState(null, '', location.pathname + location.search); } catch (e) {}
    var r = parsePlan(text);
    if (r.errors.length || !r.items.length) { state = null; return; }
    state = { items: r.items, idx: 0, rep: 1, loop: r.loop, active: true };
    save(); loading = false; navigating = false;
    // playback begins from tick() once the YouTube player exists
  }
  fromHash();

  function init() { buildHud(); updateHud(); setInterval(tick, 500); }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init); else init();

  // test hook (only present when a test sets window.__RPP_TEST__ before the script runs)
  if (window.__RPP_TEST__) window.__rpp = { tick: tick, start: startPlan, state: function () { return state; }, advance: advance, parsePlan: parsePlan };
})();
