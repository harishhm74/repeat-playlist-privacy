// Opens the editor as a side panel (Chrome, Edge) or sidebar (Firefox) when the toolbar button is clicked.
// Browsers without either fall back to a normal tab.
var api = (typeof browser !== 'undefined') ? browser : chrome;

function openTab() { api.tabs.create({ url: api.runtime.getURL('editor.html') }); }

if (api.sidePanel && api.sidePanel.setPanelBehavior) {
  api.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }).catch(function () {});
  api.runtime.onInstalled.addListener(function () {
    api.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }).catch(function () {});
  });
  // Only reached if the panel behavior could not be set.
  api.action.onClicked.addListener(function (tab) {
    var p = api.sidePanel.open ? api.sidePanel.open({ windowId: tab.windowId }) : Promise.reject();
    Promise.resolve(p).catch(openTab);
  });
} else if (api.sidebarAction && api.sidebarAction.toggle) {
  api.action.onClicked.addListener(function () { api.sidebarAction.toggle(); });
} else {
  api.action.onClicked.addListener(openTab);
}
